# Dracula for [Highlight.js](http://highlightjs.org)

> A dark theme for [Highlight.js](http://highlightjs.org).

![Screenshot](./screenshot.png)

## Install

All instructions can be found at [draculatheme.com/highlightjs](https://draculatheme.com/highlightjs).

## Team

This theme is maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/dracula/highlightjs/graphs/contributors).

[![Denis Ciccale](https://avatars0.githubusercontent.com/u/539546?v=3&s=70)](https://github.com/dciccale) |
--- |
[Denis Ciccale](https://github.com/dciccale) |

## License

[MIT License](./LICENSE)
